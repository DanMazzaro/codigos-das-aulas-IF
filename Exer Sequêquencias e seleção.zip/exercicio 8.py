usuario = input('digite a senha: ')

senha = 'python123'

if usuario == senha:
    print('a senha esta correta')
else:
    print('senha incorreta')