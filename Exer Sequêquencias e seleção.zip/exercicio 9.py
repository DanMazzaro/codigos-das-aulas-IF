nota = int(input('qual a nota? '))
if nota >= 90 and nota <= 100:
    print('nota A')
elif nota >= 80 and nota <= 89:
    print('nota B')
if nota >= 70 and nota <= 79:
    print('nota C')
if nota >= 60 and nota <= 69:
    print('nota D')
if nota >= 0 and nota <= 59:
    print('nota F')