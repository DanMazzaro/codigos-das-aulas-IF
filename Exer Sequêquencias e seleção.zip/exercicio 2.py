n1 = int(input('digite um numero: '))
n2 = int(input('digite um numero: '))

if n1 > n2:
    print(f'o maior é o',n1,)
elif n1 == n2:
    print(f'os dois numeros são iguais')
else:
    print(f'o maior é',n2 )