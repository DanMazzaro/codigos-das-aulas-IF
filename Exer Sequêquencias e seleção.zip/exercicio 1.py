numero = int(input("digite um numero: "))
if numero > 0:
    print(f'o numero ', numero,'é positivo')
else:
    print(f'o numero', numero, 'é negativo')