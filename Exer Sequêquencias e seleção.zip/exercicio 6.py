lado1 = float(input('Digite um número para ser o lado 1 do triângulo: '))
lado2 = float(input('Digite um número para ser o lado 2 do triângulo: '))
lado3 = float(input('Digite um número para ser o lado 3 do triângulo: '))


if lado1 + lado2 > lado3 and lado2 + lado3 > lado1 and lado1 + lado3 > lado2:

    if lado1 == lado2 == lado3:
        print('esse triângulo é equilátero')
    elif lado1 == lado2 or lado1 == lado3 or lado2 == lado3:
        print('esse triângulo é isósceles')
    else:
        print('esse triângulo é escaleno')
else:
    print('não é um triangulo válido')
